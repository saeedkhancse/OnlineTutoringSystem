function validate()
{
 
   if( document.myForm.user_id.value == "" )
   {
     alert( "Please provide your id" );
     document.myForm.district.focus() ;
     return false;
   }
   if( document.myForm.pass.value == "" )
   {
     alert( "Please provide your password!" );
     document.myForm.area.focus() ;
     return false;
   }
   
    if( document.myForm.cpass.value == "" )
   {
     alert( "Please confirm your password!" );
     document.myForm.area.focus() ;
     return false;
   }
   
    if( document.myForm.cpass.value !== document.myForm.pass.value )
   {
     alert( "Please provide same pass!" );
     document.myForm.area.focus() ;
     return false;
   }
   
   if( document.myForm.email.value == "" )
   {
     alert( "Please provide your email!" );
	 document.myForm.medium.focus() ;
     return false;
   }
   
   if( document.myForm.mbl.value == "" )
   {
     alert( "Please provide your mobile no!" );
	 document.myForm.medium.focus() ;
     return false;
   }
   return( true );
}